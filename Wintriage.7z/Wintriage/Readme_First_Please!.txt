﻿- Wintriage -
Developed by Lorenzo Martínez (@lawwait) and tested by Miguel Ángel Lara (@MiguelALara) - Securízame
License: Free use and distribution. If you have any suggestions, please write us at contacto@securizame.com

[Description]
It is a tool that aims to carry out an extraction of different sources of evidence from a Windows system.

It generates a directory structure that will contain the extracted / generated elements.
Two executable files are delivered: Wintriage.exe (for 32-bit systems) and Wintriage64.exe (for 64-bit systems)

It is compatible with Windows operating systems from XP / 2003 onwards (up to Windows 10v20H2 and Windows 2019)

It has two modes of execution:

+ Live Response mode:
	- Extracts information from the system where you run it
	- Follows the logical order of extraction of evidence from highest to lowest volatility
+ Offline mode:
	- It requires an NTFS file system that contains an installation of a Windows system to be mounted on a logical drive
	- Automatically extracts evidence in post-mortem mode. It is useful to have the different artifacts already extracted, so that they can be parsed later.

The tool allows operation in two ways:
+ GUI:
	- Automatically requires elevated privilege execution
	- Shows an intuitive interface to select the desired modules, and generates the extraction execution.
+ CLI:
	- Requires execution from a CMD session with administrator privileges.
	- Execution: Wintriage [64] .exe (/ all || / flags: mcarefpsutihrd) [zip] [egarante]
		Help:

			* /all -> Run all modules (except C drive image :)
						* /drive -> Generate C drive image:
						* /flags:mcareftsuprihd -> Choose the modules you want
							+ m -> Extract Memory
							+ c -> Execute Commands
							+ a -> Alternate Data Streams
							+ r -> System Registy
							+ e -> Extract eventos
							+ f -> Extract $MFT, $LogFile, $J
							+ t -> Extract Prefecth
							+ s -> Setupapi Files
							+ u -> User info
							+ p -> Trash Bin
							+ r -> SRUM
							+ i -> Spool info
							+ h -> Shadow Copies
							+ d -> Active Directory
						* zip -> When finished make a single file and calculate SHA256
						* egarante -> When finished make a single file, calculate SHA256 and send it to egarante (requires file egarante.txt)


[Zip compression]
Generates a single compressed file with all the extracted content, with a .7z extension

[Integration with eGarante]

It involves the compression of all the extracted content, with a .7z extension, and generates a file containing the path of the file and its SHA-256 hash.
If you have an account in egarante, which allows you to use the eG stamp service (it is explained below how to configure the file with user data), a base64 of the previous file will be sent to egarante.
Minutes later, an email will arrive to the account configured in the file, with a PDF document generated and signed by eGarante, with the content of the file, as well as its SHA-1 and SHA-256.

[Instructions for eGarante]

- Generate APIKEY according to instructions at https://intranet.egarante.com/egstamp/dashboard

- Create file "egarante.txt" with the following structure:
auth = SHA256 [your email + generated apikey]
api_key = [generated apikey]
email = [your email]

[Distribution]
The minimal Wintriage distribution contains the following:
- Wintriage.exe
- Wintriage64.exe
- Leeme_primero_anda.txt
- Readme_First_Please.txt
- Tools Directory
- Tools\ADSecurizame.exe file

[Auxiliary tools]
Wintriage is based on the execution of operating system commands, as well as other complementary tools that allow you to perform other tasks.
Due to their license, and their different distribution policies, we indicate under these lines the download path of each one of them. They should go directly set in the Tools directory:

- https://accessdata.com/product-download/windows-32bit-3-1-1 -> Leave uncompressed the directory ftkimagercli
- https://download.sysinternals.com/files/SysinternalsSuite.zip -> Uncompress on the directory SysinternalsSuite
- https://belkasoft.com/ram-capturer -> Ramcapture(64).exe + RamCaptureDriver(64).sys
- https://github.com/jschicht/ExtractUsnJrnl/commit/master -> ExtractUsnJrnl.exe and ExtractUsnJrnl64.exe (Important!!! Version 1.0.0.2*)
- https://www.7-zip.org/download.html (Download instalable version and once installed get 7z.dll, 7z.exe, 7za.dll, 7za.exe and 7zxa.dll files from instalation path)
- https://nirsoft.net -> cports.exe, cports64.exe and lastactivityview.exe
- http://www.parmavex.co.uk/winaudit.html -> Winaudit.exe
- https://www.magnetforensics.com/resources/encrypted-disk-detector/ -> EDD.exe (Current version is 3.0.1. If you get version 2.X of this tool, download it in the directory Tools and rename it as edd_old.exe, besides the new one)
- https://github.com/jschicht/RawCopy/commit/master -> Rawcopy.exe and rawcopy64.exe (Important!!! Version 1.0.0.9*)
- https://github.com/jschicht/RawCopy/releases/download/1.0.0.19/RawCopy_v1.0.0.19_.Win2000.zip -> Uncompress and rename to Rawcopy2003.exe  
- https://github.com/proneer/Tools/tree/master/forecopy -> forecopy_handy.exe
- https://github.com/AJMartel/IRTriage/blob/master/Compile/Tools/sleuthkit-4.2.0/bin/icat.exe -> icat.exe (Important!! Download this version from this source, as it does not depend on other libraries, having everything it needs included in this single exe)
- https://kanguru.zendesk.com/hc/en-us/articles/235228027-SHA256-Checksum-Utilities -> sha256sum.exe
